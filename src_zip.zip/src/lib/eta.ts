import { Match, Player, ETAResult, Config } from '@/types';
import { getAllDocuments, getDocument, updateDocument } from './firestore-helpers';

const DEFAULT_DURATION_15 = 20;
const DEFAULT_DURATION_21 = 30;
const DEFAULT_DURATION_11 = 15;
const MOVING_AVERAGE_SIZE = 10;
const MIN_DURATION = 3;
const MAX_DURATION = 40;

export async function recordMatchDuration(matchId: string): Promise<void> {
  const match = await getDocument<Match>('matches', matchId);
  if (!match || !match.start_time || !match.end_time) return;
  
  const durationMinutes = (match.end_time.toMillis() - match.start_time.toMillis()) / (1000 * 60);
  
  if (durationMinutes < MIN_DURATION || durationMinutes > MAX_DURATION) return;
  
  const config = await getDocument<Config>('config', 'system');
  if (!config) return;
  
  const points = getMatchPoints(match);
  const key = points === 21 ? 'recent_durations_21' : 'recent_durations_15';
  
  const recentDurations = (config as any)[key] || [];
  recentDurations.push(durationMinutes);
  
  if (recentDurations.length > MOVING_AVERAGE_SIZE) {
    recentDurations.shift();
  }
  
  const avgDuration = recentDurations.reduce((a: number, b: number) => a + b, 0) / recentDurations.length;
  const avgKey = points === 21 ? 'avg_match_duration_21' : 'avg_match_duration_15';
  
  await updateDocument('config', 'system', {
    [key]: recentDurations,
    [avgKey]: avgDuration
  });
}

export async function searchPlayerByName(name: string): Promise<ETAResult | null> {
  const players = await getAllDocuments<Player>('players');
  const player = players.find(p => p.name.includes(name));
  
  if (!player) return null;
  
  const matches = await getAllDocuments<Match>('matches');
  const playerMatches = matches.filter(m =>
    m.player1_id === player.id ||
    m.player2_id === player.id ||
    m.player3_id === player.id ||
    m.player4_id === player.id
  );
  
  const waitingMatches = playerMatches.filter(m => m.status === 'waiting');
  const playingMatches = playerMatches.filter(m => m.status === 'playing' || m.status === 'calling');
  
  if (waitingMatches.length === 0) {
    if (playingMatches.length > 0) {
      return {
        minutes: 0,
        detail: '現在試合中または呼び出し中です',
        next_court: playingMatches[0].court_id,
        matches_before: 0
      };
    }
    return {
      minutes: 0,
      detail: '待機中の試合はありません',
      next_court: null,
      matches_before: 0
    };
  }
  
  const config = await getDocument<Config>('config', 'system');
  const avgDuration15 = (config as any)?.avg_match_duration_15 || DEFAULT_DURATION_15;
  const avgDuration21 = (config as any)?.avg_match_duration_21 || DEFAULT_DURATION_21;
  
  const courts = await getAllDocuments('courts');
  const activeCourts = courts.filter((c: any) => c.is_active).length;
  
  const earliestMatch = waitingMatches.sort((a, b) => 
    a.created_at.toMillis() - b.created_at.toMillis()
  )[0];
  
  const matchesBefore = matches.filter(m =>
    m.status === 'waiting' &&
    m.created_at.toMillis() < earliestMatch.created_at.toMillis()
  ).length;
  
  const avgDuration = getMatchPoints(earliestMatch) === 21 ? avgDuration21 : avgDuration15;
  const estimatedMinutes = Math.ceil((matchesBefore / activeCourts) * avgDuration);
  
  return {
    minutes: estimatedMinutes,
    detail: `約${estimatedMinutes}分後（前に${matchesBefore}試合）`,
    next_court: null,
    matches_before: matchesBefore
  };
}

function getMatchPoints(match: Match): 15 | 21 | 11 {
  if (match.tournament_type === 'team_battle') return 11;
  if (match.tournament_type === 'mixed_doubles') return 15;
  return match.round >= 3 ? 21 : 15;
}
