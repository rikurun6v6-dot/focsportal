'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { getAllPlayers, setDocument, deleteDocument, updateDocument } from '@/lib/firestore-helpers';
import type { Player, Gender, Division } from '@/types';
import { Trash2, UserPlus, UserX } from 'lucide-react';

export default function PlayerManager() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPlayer, setNewPlayer] = useState({
    name: '',
    gender: 'male' as Gender,
    division: 1 as Division,
    team_id: '',
  });

  useEffect(() => {
    loadPlayers();
  }, []);

  const loadPlayers = async () => {
    setLoading(true);
    const data = await getAllPlayers();
    setPlayers(data);
    setLoading(false);
  };

  const handleAddPlayer = async () => {
    if (!newPlayer.name.trim()) {
      alert('名前を入力してください');
      return;
    }

    const timestamp = Date.now();
    const safeName = newPlayer.name.replace(/\s+/g, '_');
    const id = `player_${timestamp}_${safeName}`;

    const player: Player = {
      id,
      name: newPlayer.name.trim(),
      gender: newPlayer.gender,
      division: newPlayer.division,
      team_id: newPlayer.team_id.trim() || '',
      is_active: true,
      total_points: 0,
    };

    await setDocument('players', player);
    await loadPlayers();

    setNewPlayer({
      name: '',
      gender: 'male',
      division: 1,
      team_id: '',
    });
  };

  const handleDeletePlayer = async (playerId: string) => {
    if (!confirm('この選手を削除してもよろしいですか?')) return;
    await deleteDocument('players', playerId);
    await loadPlayers();
  };

  const handleToggleActive = async (player: Player) => {
    await updateDocument('players', player.id, {
      is_active: !player.is_active,
    });
    await loadPlayers();
  };

  if (loading) {
    return <p className="text-gray-600 dark:text-gray-400">読み込み中...</p>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm md:text-base">新規選手登録</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
            <Input
              placeholder="名前"
              value={newPlayer.name}
              onChange={(e) => setNewPlayer({ ...newPlayer, name: e.target.value })}
              className="flex-1 min-w-[120px]"
            />
            <select
              value={newPlayer.gender}
              onChange={(e) => setNewPlayer({ ...newPlayer, gender: e.target.value as Gender })}
              className="h-10 rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 px-3 text-sm"
            >
              <option value="male">男性</option>
              <option value="female">女性</option>
            </select>
            <select
              value={newPlayer.division}
              onChange={(e) => setNewPlayer({ ...newPlayer, division: parseInt(e.target.value) as Division })}
              className="h-10 rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 px-3 text-sm"
            >
              <option value="1">1部</option>
              <option value="2">2部</option>
            </select>
            <Input
              placeholder="チームID (任意)"
              value={newPlayer.team_id}
              onChange={(e) => setNewPlayer({ ...newPlayer, team_id: e.target.value })}
              className="flex-1 min-w-[120px]"
            />
            <Button onClick={handleAddPlayer} className="w-full">
              <UserPlus className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              <span className="hidden md:inline">追加</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm md:text-base">選手一覧 ({players.length}名)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>名前</TableHead>
                  <TableHead className="hidden sm:table-cell">性別</TableHead>
                  <TableHead className="hidden sm:table-cell">部門</TableHead>
                  <TableHead>ポイント</TableHead>
                  <TableHead>状態</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {players.map((player) => (
                  <TableRow key={player.id}>
                    <TableCell className="font-medium break-words max-w-[150px]">
                      {player.name}
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <Badge variant={player.gender === 'male' ? 'default' : 'secondary'}>
                        {player.gender === 'male' ? '男' : '女'}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      {player.division}部
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{player.total_points || 0}pt</Badge>
                    </TableCell>
                    <TableCell>
                      {player.is_active ? (
                        <Badge variant="default" className="bg-green-500">参加中</Badge>
                      ) : (
                        <Badge variant="destructive">棄権</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleToggleActive(player)}
                        >
                          <UserX className="w-3 h-3 md:w-4 md:h-4" />
                          <span className="hidden md:inline ml-1">
                            {player.is_active ? '棄権' : '復帰'}
                          </span>
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeletePlayer(player.id)}
                        >
                          <Trash2 className="w-3 h-3 md:w-4 md:h-4" />
                          <span className="hidden md:inline ml-1">削除</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
