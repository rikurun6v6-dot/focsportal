"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  getAllPlayers, 
  createMatches 
} from "@/lib/firestore-helpers";
import { 
  generateRandomPairs, 
  generateMixedPairs,
  generateTournamentBracket,
  getRoundName,
  getMatchPoints
} from "@/lib/tournament-generator";
import type { Player, TournamentType, Division, Match } from "@/types";
import { Timestamp } from "firebase/firestore";

export default function TournamentGenerator() {
  const [tournamentType, setTournamentType] = useState<TournamentType>("mens_doubles");
  const [division, setDivision] = useState<Division>(1);
  const [generating, setGenerating] = useState(false);
  const [message, setMessage] = useState("");
  const [pairCount, setPairCount] = useState(0);

  const handleGenerate = async () => {
    setGenerating(true);
    setMessage("");

    try {
      // プレイヤーを取得
      const players = await getAllPlayers();
      
      if (players.length === 0) {
        setMessage("✗ 参加者が登録されていません。先にCSVをインポートしてください。");
        setGenerating(false);
        return;
      }

      // ペアを生成
      let pairs: [Player, Player][] = [];
      let errors: string[] = [];

      if (tournamentType === "mixed_doubles") {
        const result = generateMixedPairs(players, division);
        pairs = result.pairs;
        errors = result.errors;
      } else {
        const result = generateRandomPairs(players, tournamentType, division);
        pairs = result.pairs;
        errors = result.errors;
      }

      if (pairs.length === 0) {
        setMessage(`✗ ペアを生成できませんでした: ${errors.join(", ")}`);
        setGenerating(false);
        return;
      }

      setPairCount(pairs.length);

      // トーナメントブラケットを生成
      const bracket = generateTournamentBracket(pairs.length);

      // 試合データを作成
      const matches: Omit<Match, "id">[] = [];
      let pairIndex = 0;

      for (let round = 1; round <= bracket.rounds; round++) {
        const matchesInRound = bracket.matchesPerRound[round - 1];
        const points = getMatchPoints(round, bracket.rounds);

        for (let m = 0; m < matchesInRound; m++) {
          // 1回戦のみペアを割り当て、それ以降は空（勝者が決まってから埋める）
          if (round === 1 && pairIndex < pairs.length - 1) {
            const pair1 = pairs[pairIndex];
            const pair2 = pairs[pairIndex + 1];
            
            matches.push({
              tournament_type: tournamentType,
              round,
              player1_id: pair1[0].id,
              player2_id: pair2[0].id,
              player3_id: pair1[1].id,
              player4_id: pair2[1].id,
              status: "waiting",
              court_id: null,
              score_p1: 0,
              score_p2: 0,
              winner_id: null,
              start_time: null,
              end_time: null,
              created_at: Timestamp.now(),
              updated_at: Timestamp.now(),
            });

            pairIndex += 2;
          } else if (round === 1) {
            // 奇数ペアの場合、最後のペアは不戦勝（BYE）
            break;
          } else {
            // 2回戦以降は空の試合を作成（勝者が決まってから埋める）
            matches.push({
              tournament_type: tournamentType,
              round,
              player1_id: "",
              player2_id: "",
              status: "waiting",
              court_id: null,
              score_p1: 0,
              score_p2: 0,
              winner_id: null,
              start_time: null,
              end_time: null,
              created_at: Timestamp.now(),
              updated_at: Timestamp.now(),
            });
          }
        }
      }

      // Firestoreに登録
      const { success, errors: createErrors } = await createMatches(matches);

      if (createErrors.length > 0) {
        setMessage(`⚠ ${success}試合を作成しました（${createErrors.length}件のエラー）`);
      } else {
        const tournamentName = getTournamentName(tournamentType);
        const divisionName = division === 1 ? "1部" : "2部";
        setMessage(
          `✓ ${tournamentName} ${divisionName} のトーナメントを作成しました
` +
          `${pairs.length}組 / ${bracket.rounds}ラウンド / ${success}試合`
        );
      }
    } catch (error) {
      setMessage(`✗ エラー: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">種目</label>
          <select 
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800"
            value={tournamentType}
            onChange={(e) => setTournamentType(e.target.value as TournamentType)}
            disabled={generating}
          >
            <option value="mens_doubles">男子ダブルス</option>
            <option value="womens_doubles">女子ダブルス</option>
            <option value="mixed_doubles">混合ダブルス</option>
            <option value="mens_singles">男子シングルス</option>
            <option value="womens_singles">女子シングルス</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">レベル</label>
          <select 
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800"
            value={division}
            onChange={(e) => setDivision(Number(e.target.value) as Division)}
            disabled={generating}
          >
            <option value="1">1部</option>
            <option value="2">2部</option>
          </select>
        </div>
      </div>

      <Button 
        className="w-full" 
        onClick={handleGenerate}
        disabled={generating}
      >
        {generating ? "生成中..." : "トーナメントを生成"}
      </Button>

      {message && (
        <div className={`p-4 rounded-lg whitespace-pre-line ${
          message.startsWith("✓") 
            ? "bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-100"
            : message.startsWith("⚠")
            ? "bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-800 dark:text-yellow-100"
            : "bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-100"
        }`}>
          {message}
        </div>
      )}

      <div className="text-xs text-gray-500">
        <p className="font-semibold mb-1">仕様:</p>
        <p>• ランダムにペアを生成してトーナメント表を作成</p>
        <p>• 準々決勝まで: 15点、準決勝・決勝: 21点</p>
        <p>• 参加者数が奇数の場合、1名が除外されます</p>
      </div>
    </div>
  );
}

function getTournamentName(type: TournamentType): string {
  switch (type) {
    case "mens_doubles": return "男子ダブルス";
    case "womens_doubles": return "女子ダブルス";
    case "mixed_doubles": return "混合ダブルス";
    case "mens_singles": return "男子シングルス";
    case "womens_singles": return "女子シングルス";
    default: return "団体戦";
  }
}
